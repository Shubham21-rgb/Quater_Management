export default{
    template:`
        <div class="col"  >
            <div class="text-center mt-2 fs-5">
                <p>Copyright@Shubham || Student @IITM || 2025</p>
            </div>
        </div>`
}