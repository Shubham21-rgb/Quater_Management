export default{
    template:`
    <div class="row border">
        <div class="col-9 border fs-2" >
        QUATER-MANAGEMENT SERVICES
        </div>
        <div class="col-3 border" >
        <router-link class="btn btn-primary my-2" to="/">Logout</router-link>
        <router-link class="btn btn-primary my-2" to="/developer/info">Info</router-link>
        </div>
    </div>`
}